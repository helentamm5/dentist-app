package com.cgi.dentistapp.controller;

import com.cgi.dentistapp.entity.DentistVisitEntity;
import com.cgi.dentistapp.service.DentistVisitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Controller
@EnableAutoConfiguration
public class VisitsController extends WebMvcConfigurerAdapter {
    @Autowired
    private DentistVisitService dentistVisitService;

    @GetMapping("/visits")
    public String showVisits(Model model) {
        model.addAttribute("visits", dentistVisitService.findAllVisits());
        return "visits";
    }

    @GetMapping("/deleteVisit/{id}")
    public String delete(@PathVariable(value = "id") Long id) {
        dentistVisitService.deleteVisitById(id);
        return "redirect:/";
    }

    @GetMapping("/showFormForUpdate/{id}")
    public String showFormForUpdate(@PathVariable ( value = "id") long id, Model model) {

        // get employee from the service
        DentistVisitEntity visit = dentistVisitService.getVisitById(id);

        // set employee as a model attribute to pre-populate the form
        model.addAttribute("visit", visit);
        return "update_visit";
    }

}
