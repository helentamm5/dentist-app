package com.cgi.dentistapp.service;

import com.cgi.dentistapp.entity.DentistVisitEntity;
import com.cgi.dentistapp.model.Dentist;
import com.cgi.dentistapp.repository.DentistRepository;
import com.cgi.dentistapp.repository.VisitsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class DentistVisitService {
    @Autowired
    private DentistRepository dentistRepository;
    @Autowired
    private VisitsRepository visitsRepository;

    public List<Dentist> findAllDentists() {
        return dentistRepository.findAll();
    }

    public List<DentistVisitEntity> findAllVisits() {
        return visitsRepository.findAll();
    }

    public void addVisit(String dentistName, Date visitTime) {
        System.out.println(dentistName);
        System.out.println(visitTime);
        DentistVisitEntity entity = new DentistVisitEntity(dentistName, visitTime);
        visitsRepository.save(entity);
    }

    public DentistVisitEntity getVisitById(long id) {
        DentistVisitEntity optional = visitsRepository.findOne(id);
        DentistVisitEntity visit = null;
        if (optional != null) {
            visit = optional;
        } else {
            throw new RuntimeException(" Visit not found for id :: " + id);
        }

        return visit;
    }

    public void deleteVisitById(long id) {
        this.visitsRepository.delete(id);
    }
}
